PBW ADVENTURE - VERCEL

Upload folder ini ke GitHub lalu import repository ke Vercel.

Agar jadwal permanen:
1. Buat/aktifkan Redis/KV yang kompatibel dengan Upstash.
2. Di Vercel > Project > Settings > Environment Variables, isi:
   KV_REST_API_URL
   KV_REST_API_TOKEN
   (kode juga mendukung UPSTASH_REDIS_REST_URL dan UPSTASH_REDIS_REST_TOKEN)
3. Redeploy.
4. Login Admin dan simpan perubahan jadwal.

Tanpa Redis/KV, website tetap tampil tetapi penyimpanan lintas perangkat tidak tersedia.
